//
//  ShangPin_XiaDan_Cell.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/12.
//  Copyright © 2018年 CKJY. All rights reserved.
//  商品下单cell

#import "BaseTableViewCell.h"

@interface ShangPin_XiaDan_Cell : BaseTableViewCell

@end
