//
//  JL_SPXX_V.m
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/20.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "JL_SPXX_V.h"

@implementation JL_SPXX_V





+(CGFloat)get_H:(id)data{
    return 75 + 15 * 2 + .5;
}

@end
