//
//  GouWuChe_Cell.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/6.
//  Copyright © 2018年 CKJY. All rights reserved.
//  购物车cell

#import "BaseTableViewCell.h"

@interface GouWuChe_Cell : BaseTableViewCell

@end
