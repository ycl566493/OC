//
//  URL_Connect.h
//  同文同书
//
//  Created by 车客网 on 2017/6/29.
//  Copyright © 2017年 XC. All rights reserved.
//

#ifndef URL_Connect_h
#define URL_Connect_h

//首页
#define Book_rqcordBook [NSString stringWithFormat:@"%@%@",URL_LJ,@"getRecommendProduct"]




#endif /* URL_Connect_h */
