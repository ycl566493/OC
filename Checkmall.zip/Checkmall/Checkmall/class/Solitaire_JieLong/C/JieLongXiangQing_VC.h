//
//  JieLongXiangQing_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/4/14.
//  Copyright © 2018年 CKJY. All rights reserved.
//  接龙详情

#import "BaseViewController.h"

@interface JieLongXiangQing_VC : BaseViewController

@property (weak, nonatomic) IBOutlet UIScrollView *scrollV;//滑动呗

@property (nonatomic,strong)  NSString *Str_JLID;//接龙id

@property (nonatomic,strong)  NSString  *str_SPID;//商品id


@end
