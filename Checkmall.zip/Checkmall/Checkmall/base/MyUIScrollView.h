//
//  MyUIScrollView.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/6.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "BaseViewController.h"


@interface MyUIScrollView : BaseViewController<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView *scrollView;

@end
