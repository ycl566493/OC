//
//  FenLei_SY_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/28.
//  Copyright © 2018年 CKJY. All rights reserved.
//  首页今日的分类列表

#import "BaseCollectionViewController.h"

@interface FenLei_SY_VC : BaseCollectionViewController

@property (nonatomic,assign)    NSInteger           select_Row;



@end
