//
//  SBCommonHeader.h
//  SBPlayer
//
//  Created by sycf_ios on 2017/4/10.
//  Copyright © 2017年 shibiao. All rights reserved.
//

#ifndef SBCommonHeader_h
#define SBCommonHeader_h
#import "Masonry.h"
#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)
#endif /* SBCommonHeader_h */
