//
//  CollectionReusableView_H.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/16.
//  Copyright © 2018年 CKJY. All rights reserved.
// UICollectionReusableView的头部

#import <UIKit/UIKit.h>

@interface CollectionReusableView_H : UICollectionReusableView

@end
