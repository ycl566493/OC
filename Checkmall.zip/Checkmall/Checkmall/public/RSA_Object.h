/*
 @author: ideawu
 @link: https://github.com/ideawu/Objective-C-RSA
*/

#import <Foundation/Foundation.h>

#define RSA_public_key @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDF3wFJC/f/5qHR30BzLpcxdRtqahoXu31tbGwg97iRhVfXxLqFp2OZqdJjkYNqCuuIzRlYSJqXURkXD3UxrbiwGAMiFqPbXW/JEXgWqsqf59tRAWhJ5Ycy0Ln03lyCnVbAtdhzoqe+vfrNTg0R/D3vMMcSO76rXvvK1zxF19vy9wIDAQAB"

@interface RSA_Object : NSObject

// return base64 encoded string
+ (NSString *)encryptString:(NSString *)str publicKey:(NSString *)pubKey;
// return raw data
+ (NSData *)encryptData:(NSData *)data publicKey:(NSString *)pubKey;
// return base64 encoded string
+ (NSString *)encryptString:(NSString *)str privateKey:(NSString *)privKey;
// return raw data
+ (NSData *)encryptData:(NSData *)data privateKey:(NSString *)privKey;

// decrypt base64 encoded string, convert result to string(not base64 encoded)
+ (NSString *)decryptString:(NSString *)str publicKey:(NSString *)pubKey;
+ (NSData *)decryptData:(NSData *)data publicKey:(NSString *)pubKey;
+ (NSString *)decryptString:(NSString *)str privateKey:(NSString *)privKey;
+ (NSData *)decryptData:(NSData *)data privateKey:(NSString *)privKey;

@end
