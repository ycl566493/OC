//
//  ZhuanXiang_VC.h
//  车客生鲜
//
//  Created by 杨成龙MAC on 2018/3/3.
//  Copyright © 2018年 YCL. All rights reserved.
//  团购

#import "BaseViewController.h"

@interface ZhuanXiang_VC : BaseViewController

@property (nonatomic,assign)BOOL            bool_TZ;//跳转方式 yes 导航条 no 模态

@end
