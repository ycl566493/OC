//
//  DanPin_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/15.
//  Copyright © 2018年 CKJY. All rights reserved.
//  单品view

#import "MyUIView.h"

@interface DanPin_V : MyUIView

@end
