//
//  ShangPin_MS_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/12.
//  Copyright © 2018年 CKJY. All rights reserved.
//  商品描述模块

#import "MyUIView.h"

@interface ShangPin_MS_V : MyUIView

@property (nonatomic,copy)NSString  *str_Title;

@end
