//
//  SouSuo_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/20.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "BaseViewController.h"

@interface SouSuo_VC : BaseViewController


@property (weak, nonatomic) IBOutlet UIScrollView *scrollV;//滑动

@end
