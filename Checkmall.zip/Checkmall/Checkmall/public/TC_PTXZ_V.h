//
//  TC_PTXZ_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/17.
//  Copyright © 2018年 CKJY. All rights reserved.
//  弹出拼团须知

#import "MyUIView.h"

@interface TC_PTXZ_V : MyUIView


@property (weak, nonatomic) IBOutlet UILabel *lbl_Name;//标题

@property (weak, nonatomic) IBOutlet UIScrollView *scrollV;//滑动背景

@property (weak, nonatomic) IBOutlet UIButton *btn_GB;//关闭按钮















@end
