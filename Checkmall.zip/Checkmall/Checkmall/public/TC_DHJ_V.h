//
//  TC_DHJ_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/17.
//  Copyright © 2018年 CKJY. All rights reserved.
//  弹出兑换券

#import "MyUIView.h"

@interface TC_DHJ_V : MyUIView


@property (weak, nonatomic) IBOutlet UILabel *lbl_Name;//标题

@property (weak, nonatomic) IBOutlet UIButton *btn_GB;//关闭按钮















@end
