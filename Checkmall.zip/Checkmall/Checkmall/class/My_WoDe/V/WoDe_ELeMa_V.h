//
//  WoDe_ELeMa_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/6.
//  Copyright © 2018年 CKJY. All rights reserved.
//  饿了吗

#import "MyUIView.h"

@interface WoDe_ELeMa_V : MyUIView

@end
