//
//  YinDaoYe_VC.h
//  Created by 杨成龙MAC on 2017/7/22.
//  Copyright © 2017年 XC. All rights reserved.
//  引导页

#import "BaseViewController.h"

@interface YinDaoYe_VC : BaseViewController

+(BOOL)if_YD;//判断是否需要引导页

@end
