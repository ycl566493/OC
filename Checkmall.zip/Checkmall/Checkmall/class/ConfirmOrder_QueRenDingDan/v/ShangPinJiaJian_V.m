//
//  ShangPinJiaJian_V.m
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/13.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "ShangPinJiaJian_V.h"

@implementation ShangPinJiaJian_V





+(CGFloat)get_H{
    return 52;
}

@end
