//
//	ShangPin_Model_Comment.h
//	Copyright © 2018. All rights reserved.
//

//	Model file Generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

#import <UIKit/UIKit.h>

@interface ShangPin_Model_Comment : NSObject

@property (nonatomic, strong) NSObject * comInfo;
@property (nonatomic, assign) NSInteger comNum;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;
@end
