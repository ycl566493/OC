//
//  ZhiFuChengGong_JL_VC.m
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/19.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "ZhiFuChengGong_JL_VC.h"

@interface ZhiFuChengGong_JL_VC ()

@end

@implementation ZhiFuChengGong_JL_VC

- (void)viewDidLoad {
    [super viewDidLoad];

    [self init_UI];

}

-(void)init_UI{
    
}

@end
