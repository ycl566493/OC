//
//  ZhuanXiang_ShangPin_Cell.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/7.
//  Copyright © 2018年 CKJY. All rights reserved.
//  团购Cell

#import "BaseTableViewCell.h"

@interface ZhuanXiang_ShangPin_Cell : BaseTableViewCell

@end
