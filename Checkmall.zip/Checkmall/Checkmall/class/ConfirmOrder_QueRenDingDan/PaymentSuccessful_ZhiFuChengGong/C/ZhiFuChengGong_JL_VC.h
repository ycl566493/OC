//
//  ZhiFuChengGong_JL_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/19.
//  Copyright © 2018年 CKJY. All rights reserved.
//  接龙支付成功

#import "BaseTableViewController.h"

@interface ZhiFuChengGong_JL_VC : BaseTableViewController

@end
