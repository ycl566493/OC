//
//  YouHuiJuan_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/16.
//  Copyright © 2018年 CKJY. All rights reserved.
//  优惠劵

#import "BaseTableViewController.h"

@interface YouHuiJuan_VC : BaseTableViewController



@end
