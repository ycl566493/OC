//
//  FenLei_H_Title_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/6.
//  Copyright © 2018年 CKJY. All rights reserved.
//  分类标题

#import "MyUIView.h"

@interface FenLei_H_Title_V : MyUIView

@end
