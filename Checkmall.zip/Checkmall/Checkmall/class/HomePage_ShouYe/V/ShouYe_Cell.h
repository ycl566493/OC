//
//  ShouYe_Cell.h
//  车客生鲜
//
//  Created by 杨成龙MAC on 2018/3/5.
//  Copyright © 2018年 YCL. All rights reserved.
//  首页商品cell

#import "BaseCollectionViewCell.h"

@interface ShouYe_Cell : BaseCollectionViewCell

@end
