//
//  PinTuanXuZhi_V.m
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/14.
//  Copyright © 2018年 CKJY. All rights reserved.
//

#import "PinTuanXuZhi_V.h"

@implementation PinTuanXuZhi_V


#pragma mark- 查看详情
- (IBAction)btn_XX:(id)sender {
    
}



+(CGFloat)get_H:(id)data{
    return 135;
}

@end
