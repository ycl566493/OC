//
//	ShangPin_Model_SlidsUrlList.h
//	Copyright © 2018. All rights reserved.
//

//	Model file Generated using JSONExport: https://github.com/Ahmed-Ali/JSONExport

#import <UIKit/UIKit.h>

@interface ShangPin_Model_SlidsUrlList : NSObject

@property (nonatomic, strong) NSString * path;

-(instancetype)initWithDictionary:(NSDictionary *)dictionary;
@end
