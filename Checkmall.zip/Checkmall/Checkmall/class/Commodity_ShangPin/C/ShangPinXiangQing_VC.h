//
//  ShangPinXiangQing_VC.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/10.
//  Copyright © 2018年 CKJY. All rights reserved.
//  商品详情

#import "BaseViewController.h"

@interface ShangPinXiangQing_VC : BaseViewController

@end
