//
//  MyButton.h
//  同文同书
//
//  Created by 杨成龙MAC on 2017/7/2.
//  Copyright © 2017年 XC. All rights reserved.
//  扩展按钮 图片 文字偏移
#import <UIKit/UIKit.h>

@interface MyButton : UIButton


-(void)set_LX:(NSInteger)tpye JG:(CGFloat)JG ;//修改图片文字显示位置 1、 上图下文  2、左图又文   JG中间间隔

@end
