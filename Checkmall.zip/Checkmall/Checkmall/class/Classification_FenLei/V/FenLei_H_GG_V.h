//
//  FenLei_H_GG_V.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/6.
//  Copyright © 2018年 CKJY. All rights reserved.
//  分类广告view

#import "MyUIView.h"

@interface FenLei_H_GG_V : MyUIView

@end
