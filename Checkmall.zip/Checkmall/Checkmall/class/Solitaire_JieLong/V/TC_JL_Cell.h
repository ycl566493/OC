//
//  TC_JL_Cell.h
//  Checkmall
//
//  Created by 杨成龙MAC on 2018/3/19.
//  Copyright © 2018年 CKJY. All rights reserved.
//  弹出接龙

#import <UIKit/UIKit.h>

@interface TC_JL_Cell : UITableViewCell


+(CGFloat)get_H;

@end
