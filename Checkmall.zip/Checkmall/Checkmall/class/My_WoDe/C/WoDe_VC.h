//
//  WoDe_VC.h
//  车客生鲜
//
//  Created by 杨成龙MAC on 2018/3/3.
//  Copyright © 2018年 YCL. All rights reserved.
//  我的

#import "MyUIScrollView.h"

@interface WoDe_VC : MyUIScrollView

@end
